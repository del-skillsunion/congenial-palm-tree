# Congenial Palm Tree

```
git clone
git add .
git commit -m "the commit message"
git push
```


To initialize the node application
```
npm init
```